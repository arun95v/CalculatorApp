package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

@Composable
fun CalculatorApp() {
    var expression by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("0") }

    fun press(key: String) {
        when (key) {
            "AC" -> { expression = ""; display = "0" }
            "⌫" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                    display = expression.ifEmpty { "0" }
                }
            }
            "=" -> {
                try {
                    val result = evaluate(expression)
                    display = format(result)
                    expression = display
                } catch (_: Exception) {
                    display = "Error"
                    expression = ""
                }
            }
            "±" -> {
                if (expression.isNotEmpty() && expression.toDoubleOrNull() != null) {
                    expression = if (expression.startsWith("-")) expression.drop(1) else "-$expression"
                    display = expression
                }
            }
            "%" -> {
                try {
                    if (expression.isNotEmpty()) {
                        val v = evaluate(expression) / 100.0
                        expression = format(v)
                        display = expression
                    }
                } catch (_: Exception) {}
            }
            else -> {
                if (display == "Error") { expression = ""; display = "0" }
                expression += key
                display = expression
            }
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = display,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 24.dp),
                    fontSize = 48.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                    maxLines = 2
                )
                val rows = listOf(
                    listOf("AC", "⌫", "%", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "−"),
                    listOf("1", "2", "3", "+"),
                    listOf("±", "0", ".", "=")
                )
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { key ->
                            Button(
                                onClick = { press(key) },
                                modifier = Modifier.weight(1f).aspectRatio(1.25f).padding(vertical = 5.dp),
                                shape = RoundedCornerShape(20.dp)
                            ) { Text(key, fontSize = 24.sp) }
                        }
                    }
                }
            }
        }
    }
}

private fun format(x: Double): String {
    if (abs(x) < 1e-10) return "0"
    return if (x % 1.0 == 0.0) x.toLong().toString() else "%.10f".format(x).trimEnd('0').trimEnd('.')
}

private fun evaluate(input: String): Double {
    val s = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "")
    if (s.isEmpty()) throw IllegalArgumentException()
    var pos = 0
    fun expression(): Double {
        var v = term()
        while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
            val op = s[pos++]
            val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }
    fun primary(): Double {
        if (pos >= s.length) throw IllegalArgumentException()
        if (s[pos] == '(') {
            pos++
            val v = expression()
            if (pos >= s.length || s[pos++] != ')') throw IllegalArgumentException()
            return v
        }
        val start = pos
        if (s[pos] == '+' || s[pos] == '-') pos++
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException()
        return s.substring(start, pos).toDouble()
    }
    fun factor(): Double {
        if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
            val op = s[pos++]
            val v = factor()
            return if (op == '-') -v else v
        }
        return primary()
    }
    fun term(): Double {
        var v = factor()
        while (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
            val op = s[pos++]
            val r = factor()
            if (op == '/' && r == 0.0) throw ArithmeticException()
            v = if (op == '*') v * r else v / r
        }
        return v
    }
    val result = expression()
    if (pos != s.length) throw IllegalArgumentException()
    return result
}
